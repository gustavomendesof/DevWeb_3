package trabalhoavaliativo;
public class Viagem {
    private String nome;
    public String Destino;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    

    
}
